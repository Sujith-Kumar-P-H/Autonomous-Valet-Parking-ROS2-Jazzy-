"""pytest tests for the ROS-independent core (run by `colcon test` or `pytest`)."""
import math

from av_valet.core import lot as L
from av_valet.core.hybrid_astar import HybridAStar, infer_directions
from av_valet.core.vehicle import Bicycle


def test_bicycle_circle():
    b = Bicycle((0, 0, 0))
    b.delta = 0.3
    for _ in range(400):
        b.step(1.0, 0.3, 0.05)
    R = L.WHEELBASE / math.tan(0.3)
    assert abs(math.hypot(b.x, b.y - R) - R) < 0.05


def test_plan_reverse_bay():
    pl = HybridAStar(L.LotWorld().static)
    r = pl.plan(L.START_POSE, L.bay_goal_pose(6, True))
    assert r['ok'] and -1 in infer_directions(r['path'])


def test_occupied_goal_rejected():
    r = HybridAStar(L.LotWorld().static).plan(L.START_POSE, L.bay_goal_pose(0))
    assert not r['ok']
