"""Launch the whole simulated valet-parking system.

    ros2 launch av_valet valet.launch.py                       # defaults: bay 6, reverse-in, cart appears, RViz on, recording on
    ros2 launch av_valet valet.launch.py rviz:=false           # headless (no window)
    ros2 launch av_valet valet.launch.py bay:=12 reverse_in:=false cart:=false
"""
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, RegisterEventHandler
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
import os


def generate_launch_description():
    rviz_cfg = os.path.join(get_package_share_directory('av_valet'), 'rviz', 'valet.rviz')
    bay = ParameterValue(LaunchConfiguration('bay'), value_type=int)
    reverse_in = ParameterValue(LaunchConfiguration('reverse_in'), value_type=bool)
    cart = ParameterValue(LaunchConfiguration('cart'), value_type=bool)
    recorder = Node(package='av_valet', executable='recorder_node', name='recorder_node', output='screen',
                    parameters=[{'bay': bay}], condition=IfCondition(LaunchConfiguration('record')))
    return LaunchDescription([
        DeclareLaunchArgument('bay', default_value='6', description='empty bay index (3, 6, 12 or 16)'),
        DeclareLaunchArgument('reverse_in', default_value='true', description='back into the bay'),
        DeclareLaunchArgument('cart', default_value='true', description='surprise shopping cart in the aisle'),
        DeclareLaunchArgument('rviz', default_value='true', description='open RViz2'),
        DeclareLaunchArgument('record', default_value='true', description='save images + video to ~/robot_sim_outputs/av_valet'),
        Node(package='av_valet', executable='map_node', name='map_node', output='screen'),
        Node(package='av_valet', executable='vehicle_sim_node', name='vehicle_sim_node', output='screen',
             parameters=[{'cart_enabled': cart}]),
        Node(package='av_valet', executable='planner_node', name='planner_node', output='screen'),
        Node(package='av_valet', executable='controller_node', name='controller_node', output='screen'),
        recorder,
        Node(package='av_valet', executable='mission_node', name='mission_node', output='screen',
             parameters=[{'bay': bay, 'reverse_in': reverse_in, 'delay': 4.0}]),
        Node(package='rviz2', executable='rviz2', name='rviz2', arguments=['-d', rviz_cfg], output='log',
             condition=IfCondition(LaunchConfiguration('rviz'))),
        # when the recorder has written the files and exits, shut the whole system down
        RegisterEventHandler(OnProcessExit(target_action=recorder, on_exit=[EmitEvent(event=Shutdown())])),
    ])
