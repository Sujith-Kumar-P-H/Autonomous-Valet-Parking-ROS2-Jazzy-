#!/usr/bin/env python3
"""map_node: publishes the (static) parking-lot map as nav_msgs/OccupancyGrid on /map (latched) and the parked cars as
visualization markers on /lot_markers (for RViz)."""
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from visualization_msgs.msg import Marker, MarkerArray

from av_valet.core import lot as L
from av_valet.ros_utils import LATCHED_QOS


class MapNode(Node):
    def __init__(self):
        super().__init__('map_node')
        self.pub_map = self.create_publisher(OccupancyGrid, '/map', LATCHED_QOS)
        self.pub_mk = self.create_publisher(MarkerArray, '/lot_markers', LATCHED_QOS)
        self.timer = self.create_timer(1.0, self.publish)       # re-publish once per second (cheap, helps late joiners)
        self.get_logger().info('map_node ready: publishing /map and /lot_markers')

    def publish(self):
        grid = L.build_static_grid()
        m = OccupancyGrid()
        m.header.frame_id, m.header.stamp = 'map', self.get_clock().now().to_msg()
        m.info.resolution, m.info.width, m.info.height = L.RES, L.W, L.H
        m.info.origin.orientation.w = 1.0
        m.data = (grid.astype('int8') * 100).ravel().tolist()
        self.pub_map.publish(m)
        arr = MarkerArray()
        for k, i in enumerate(sorted(L.OCCUPIED_BAYS)):
            x0, y0, x1, y1 = L.parked_car_rect(i)
            mk = Marker()
            mk.header.frame_id, mk.ns, mk.id, mk.type, mk.action = 'map', 'parked_cars', k, Marker.CUBE, Marker.ADD
            mk.pose.position.x, mk.pose.position.y, mk.pose.position.z = (x0 + x1) / 2, (y0 + y1) / 2, 0.7
            mk.pose.orientation.w = 1.0
            mk.scale.x, mk.scale.y, mk.scale.z = x1 - x0, y1 - y0, 1.4
            mk.color.r, mk.color.g, mk.color.b, mk.color.a = 0.2, 0.4, 0.9, 0.9
            arr.markers.append(mk)
        self.pub_mk.publish(arr)


def main(args=None):
    rclpy.init(args=args)
    node = MapNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
