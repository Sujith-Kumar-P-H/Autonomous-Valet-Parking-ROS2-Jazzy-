#!/usr/bin/env python3
"""mission_node: the 'valet dispatcher'. After `delay` seconds it assigns the vehicle a parking bay and publishes the
rear-axle goal pose on /goal_pose. (You can ALSO click "2D Goal Pose" in RViz at any time - it publishes to the same topic.)
Parameters: bay (int, empty bays are 3, 6, 12, 16), reverse_in (bool), delay (s)."""
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node

from av_valet.core import lot as L
from av_valet.ros_utils import yaw_to_quat


class MissionNode(Node):
    def __init__(self):
        super().__init__('mission_node')
        self.declare_parameter('bay', 6)
        self.declare_parameter('reverse_in', True)
        self.declare_parameter('delay', 4.0)
        self.pub = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.sent = False
        self.t0 = self.get_clock().now()
        self.create_timer(0.5, self.tick)

    def tick(self):
        if self.sent or (self.get_clock().now() - self.t0).nanoseconds * 1e-9 < self.get_parameter('delay').value:
            return
        bay = int(self.get_parameter('bay').value)
        if bay in L.OCCUPIED_BAYS:
            self.get_logger().error(f'bay {bay} is occupied; free bays: {sorted(set(range(20)) - L.OCCUPIED_BAYS)}')
            self.sent = True
            return
        x, y, th = L.bay_goal_pose(bay, bool(self.get_parameter('reverse_in').value))
        msg = PoseStamped()
        msg.header.frame_id, msg.header.stamp = 'map', self.get_clock().now().to_msg()
        msg.pose.position.x, msg.pose.position.y = float(x), float(y)
        msg.pose.orientation = yaw_to_quat(th)
        self.pub.publish(msg)
        self.sent = True
        self.get_logger().info(f'assigned bay {bay}: goal ({x:.1f}, {y:.1f}, {th:.2f} rad)')


def main(args=None):
    rclpy.init(args=args)
    node = MissionNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
