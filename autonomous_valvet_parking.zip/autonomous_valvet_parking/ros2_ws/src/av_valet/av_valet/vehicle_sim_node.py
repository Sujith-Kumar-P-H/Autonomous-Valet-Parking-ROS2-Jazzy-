#!/usr/bin/env python3
"""vehicle_sim_node: THE SIMULATOR. Replaces real hardware.
  subscribes : /cmd_vel (geometry_msgs/Twist)  linear.x = speed [m/s] (negative = reverse), angular.z = STEERING ANGLE [rad]
               (a deliberate, documented simplification - real Ackermann stacks use ackermann_msgs/AckermannDrive)
  publishes  : /odom (nav_msgs/Odometry), TF map->base_link, /scan (sensor_msgs/LaserScan, 360 deg, 180 beams),
               /vehicle_marker (RViz car body), /cart_pose (PoseStamped, when the surprise obstacle appears)
  The pose is the REAR-AXLE centre. Ground-truth localisation is assumed (map->base_link is exact)."""
import math

import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped, Twist, TransformStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from tf2_ros import TransformBroadcaster
from visualization_msgs.msg import Marker, MarkerArray

from av_valet.core import lot as L
from av_valet.core.vehicle import Bicycle, Lidar
from av_valet.ros_utils import yaw_to_quat


class VehicleSimNode(Node):
    def __init__(self):
        super().__init__('vehicle_sim_node')
        self.declare_parameter('cart_enabled', True)
        self.declare_parameter('cart_trigger_x', 9.0)       # the cart appears when the car passes this x position
        self.declare_parameter('cart_x', 17.0)
        self.declare_parameter('cart_y', 14.0)
        self.declare_parameter('seed', 0)
        self.world = L.LotWorld()
        self.veh = Bicycle(L.START_POSE)
        self.lidar = Lidar(np.random.default_rng(int(self.get_parameter('seed').value)))
        self.cmd_v, self.cmd_delta = 0.0, 0.0
        self.last_cmd_time = self.get_clock().now()
        self.cart_on = False
        self.dt = 0.02
        self.create_subscription(Twist, '/cmd_vel', self.on_cmd, 10)
        self.pub_odom = self.create_publisher(Odometry, '/odom', 10)
        self.pub_scan = self.create_publisher(LaserScan, '/scan', 10)
        self.pub_mk = self.create_publisher(MarkerArray, '/vehicle_marker', 10)
        self.pub_cart = self.create_publisher(PoseStamped, '/cart_pose', 10)
        self.tf = TransformBroadcaster(self)
        self.create_timer(self.dt, self.step)                   # 50 Hz physics
        self.create_timer(0.1, self.publish_scan_and_markers)   # 10 Hz lidar
        self.get_logger().info('vehicle_sim_node ready (kinematic bicycle, rear-axle pose)')

    def on_cmd(self, msg):
        self.cmd_v, self.cmd_delta = msg.linear.x, msg.angular.z
        self.last_cmd_time = self.get_clock().now()

    def step(self):
        if (self.get_clock().now() - self.last_cmd_time).nanoseconds > 0.5e9:      # watchdog: no commands -> stop
            self.cmd_v = 0.0
        self.veh.step(self.cmd_v, self.cmd_delta, self.dt)
        if self.get_parameter('cart_enabled').value and not self.cart_on and self.veh.x > self.get_parameter('cart_trigger_x').value:
            cx, cy = self.get_parameter('cart_x').value, self.get_parameter('cart_y').value
            self.world.add_box(cx, cy)
            self.cart_on = True
            ps = PoseStamped()
            ps.header.frame_id, ps.header.stamp = 'map', self.get_clock().now().to_msg()
            ps.pose.position.x, ps.pose.position.y, ps.pose.orientation.w = float(cx), float(cy), 1.0
            self.pub_cart.publish(ps)
            self.get_logger().warn('Shopping cart appeared in the aisle')
        now = self.get_clock().now().to_msg()
        x, y, th = self.veh.pose
        tf = TransformStamped()
        tf.header.stamp, tf.header.frame_id, tf.child_frame_id = now, 'map', 'base_link'
        tf.transform.translation.x, tf.transform.translation.y = x, y
        tf.transform.rotation = yaw_to_quat(th)
        self.tf.sendTransform(tf)
        od = Odometry()
        od.header.stamp, od.header.frame_id, od.child_frame_id = now, 'map', 'base_link'
        od.pose.pose.position.x, od.pose.pose.position.y = x, y
        od.pose.pose.orientation = yaw_to_quat(th)
        od.twist.twist.linear.x = self.veh.v
        od.twist.twist.angular.z = self.veh.v * math.tan(self.veh.delta) / L.WHEELBASE
        self.pub_odom.publish(od)

    def publish_scan_and_markers(self):
        now = self.get_clock().now().to_msg()
        ranges = self.lidar.scan(self.world, self.veh.pose)
        sc = LaserScan()
        sc.header.stamp, sc.header.frame_id = now, 'base_link'
        sc.angle_min, sc.angle_max, sc.angle_increment = -math.pi, math.pi, 2 * math.pi / self.lidar.n
        sc.range_min, sc.range_max = 0.05, float(self.lidar.max_range)
        sc.ranges = [float(r) for r in ranges]
        self.pub_scan.publish(sc)
        arr = MarkerArray()
        x, y, th = self.veh.pose
        mk = Marker()
        mk.header.frame_id, mk.ns, mk.id, mk.type, mk.action = 'map', 'vehicle', 0, Marker.CUBE, Marker.ADD
        c = (L.FRONT_END - L.REAR_OVERHANG) / 2            # body centre is ahead of the rear axle
        mk.pose.position.x, mk.pose.position.y, mk.pose.position.z = x + c * math.cos(th), y + c * math.sin(th), 0.6
        mk.pose.orientation = yaw_to_quat(th)
        mk.scale.x, mk.scale.y, mk.scale.z = L.CAR_L, L.CAR_W, 1.2
        mk.color.r, mk.color.g, mk.color.b, mk.color.a = 0.9, 0.1, 0.1, 0.95
        arr.markers.append(mk)
        if self.cart_on:
            cm = Marker()
            cm.header.frame_id, cm.ns, cm.id, cm.type, cm.action = 'map', 'cart', 1, Marker.CUBE, Marker.ADD
            cm.pose.position.x, cm.pose.position.y, cm.pose.position.z = float(self.get_parameter('cart_x').value), float(self.get_parameter('cart_y').value), 0.5
            cm.pose.orientation.w = 1.0
            cm.scale.x = cm.scale.y = cm.scale.z = 1.0
            cm.color.r, cm.color.g, cm.color.b, cm.color.a = 1.0, 0.6, 0.0, 1.0
            arr.markers.append(cm)
        self.pub_mk.publish(arr)


def main(args=None):
    rclpy.init(args=args)
    node = VehicleSimNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
