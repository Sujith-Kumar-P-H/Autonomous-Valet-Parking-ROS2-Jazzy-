#!/usr/bin/env python3
"""planner_node: Hybrid A* global planner with obstacle-aware replanning.
  subscribes : /map (latched), /odom, /scan, /goal_pose (RViz "2D Goal Pose" or mission_node), /controller_status
  publishes  : /planned_path (nav_msgs/Path; reverse segments are recognised by heading vs. direction of travel)
  logic      : plan on goal; every scan -> lidar hits NOT explained by the known map are 'unknown obstacles'; they are added
               to the planner's map; if one lies near the remaining route -> replan (max once per second).
               If the controller reports 'blocked' for > 1.5 s -> replan."""
import math

import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

from av_valet.core import lot as L
from av_valet.core.hybrid_astar import HybridAStar
from av_valet.core.vehicle import scan_points_world, unknown_obstacle_points
from av_valet.ros_utils import LATCHED_QOS, grid_from_occupancy, path_to_msg, quat_to_yaw


class PlannerNode(Node):
    def __init__(self):
        super().__init__('planner_node')
        self.static = None
        self.known = None
        self.pose = None
        self.goal = None
        self.path = None
        self.last_replan = -9.0
        self.blocked_since = None
        self.create_subscription(OccupancyGrid, '/map', self.on_map, LATCHED_QOS)
        self.create_subscription(Odometry, '/odom', self.on_odom, 10)
        self.create_subscription(LaserScan, '/scan', self.on_scan, 10)
        self.create_subscription(PoseStamped, '/goal_pose', self.on_goal, 10)
        self.create_subscription(String, '/controller_status', self.on_status, 10)
        self.pub_path = self.create_publisher(Path, '/planned_path', 10)
        self.get_logger().info('planner_node ready: waiting for /map and a goal on /goal_pose')

    def now_s(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def on_map(self, msg):
        if self.static is None:
            self.static = grid_from_occupancy(msg)
            self.known = self.static.copy()
            self.get_logger().info('map received')

    def on_odom(self, msg):
        p = msg.pose.pose
        self.pose = (p.position.x, p.position.y, quat_to_yaw(p.orientation))

    def on_goal(self, msg):
        self.goal = (msg.pose.position.x, msg.pose.position.y, quat_to_yaw(msg.pose.orientation))
        self.get_logger().info(f'new goal: x={self.goal[0]:.1f} y={self.goal[1]:.1f} yaw={math.degrees(self.goal[2]):.0f} deg')
        self.plan('goal')

    def on_status(self, msg):
        if msg.data == 'blocked':
            self.blocked_since = self.blocked_since or self.now_s()
            if self.now_s() - self.blocked_since > 1.5 and self.now_s() - self.last_replan > 1.0:
                self.blocked_since = None
                self.plan('blocked')
        else:
            self.blocked_since = None

    def plan(self, reason):
        if self.static is None or self.pose is None or self.goal is None:
            self.get_logger().warn('cannot plan yet (need map, odometry and goal)')
            return False
        self.last_replan = self.now_s()
        res = HybridAStar(self.known).plan(self.pose, self.goal)
        self.get_logger().info(f"plan ({reason}): {'OK' if res['ok'] else 'FAILED: ' + res['reason']}, "
                               f"{res['expansions']} expansions, {res['time']:.2f} s, {len(res['path'])} poses")
        if res['ok']:
            self.path = np.array(res['path'])
            self.pub_path.publish(path_to_msg(res['path'], self.get_clock().now().to_msg()))
        return res['ok']

    def on_scan(self, msg):
        if self.known is None or self.pose is None:
            return
        n = len(msg.ranges)
        rel = msg.angle_min + msg.angle_increment * np.arange(n)
        pts = scan_points_world(self.pose, np.array(msg.ranges), rel, msg.range_max)
        unk = unknown_obstacle_points(pts, self.known)
        if not len(unk):
            return
        add = np.zeros_like(self.known)
        for x, y in unk:
            add[int(y / L.RES), int(x / L.RES)] = True
        new = add & ~self.known
        if not new.any():
            return
        self.known |= L.inflate(new, 3 * L.RES * 1.01)       # near face seen only: assume ~0.75 m of depth behind it
        if self.path is None or self.goal is None or self.now_s() - self.last_replan < 1.0:
            return
        P = self.path[:, :2]
        i0 = int(np.argmin(np.hypot(P[:, 0] - self.pose[0], P[:, 1] - self.pose[1])))
        seg = P[i0:i0 + 100]
        d = np.hypot(seg[:, None, 0] - unk[None, :, 0], seg[:, None, 1] - unk[None, :, 1])
        if d.min() < 1.3:
            self.get_logger().warn('unknown obstacle near the planned route -> replanning')
            self.plan('obstacle')


def main(args=None):
    rclpy.init(args=args)
    node = PlannerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
