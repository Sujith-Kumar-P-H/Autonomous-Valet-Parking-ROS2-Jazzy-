#!/usr/bin/env python3
"""
standalone.py -- the whole valet-parking stack WITHOUT ROS (same core code the ROS nodes use).

    python standalone.py --test                  # unit/integration tests
    python standalone.py                         # run, print report, save video + images to ~/robot_sim_outputs/av_valet/
    python standalone.py --bay 12 --forward-in   # other bay / nose-first parking
    python standalone.py --no-cart               # no surprise obstacle

Mission: the vehicle enters at the left, is assigned an empty bay, plans a drivable path with Hybrid A* (including a reverse
parking manoeuvre), follows it with pure pursuit, and when a shopping cart suddenly appears in the aisle it detects the
unknown obstacle with its lidar (map differencing), replans, and parks. Simulation only.
"""
from __future__ import annotations

import argparse
import math
import sys
import time

import numpy as np

from .core import lot as L
from .core.hybrid_astar import HybridAStar
from .core.vehicle import Bicycle, Lidar, PathFollower, scan_points_world, unknown_obstacle_points
from .core.render import render_outputs, OUT_DIR


def dilate(grid, n=1):
    return L.inflate(grid, n * L.RES * 1.01)


class ValetMission:
    def __init__(self, bay=6, reverse_in=True, cart=(17.0, 14.0, 4.0), seed=0, dt=0.05, max_time=240.0):
        self.rng = np.random.default_rng(seed)
        self.world = L.LotWorld()
        self.veh = Bicycle(L.START_POSE)
        self.lidar = Lidar(self.rng)
        self.follower = PathFollower()
        self.known = self.world.static.copy()              # what the planner knows (static map + detected obstacles)
        self.static_known = self.world.static.copy()       # the original map: lidar hits NOT explained by it are 'unknown obstacles'
        self.goal = L.bay_goal_pose(bay, reverse_in)
        self.bay, self.reverse_in, self.cart, self.dt, self.max_time = bay, reverse_in, cart, dt, max_time
        self.t = 0.0
        self.log = dict(t=[], x=[], y=[], th=[], v=[], delta=[], scans=[], rel=self.lidar.rel, paths=[], cart=cart, bay=bay, events=[])
        self.plan_stats, self.collisions, self._col = [], 0, False
        self.dist = 0.0
        self.replans = 0
        self.status = 'planning'

    # ---- planning ----
    def plan(self, reason):
        planner = HybridAStar(self.known)
        res = planner.plan(self.veh.pose, self.goal)
        self.plan_stats.append(dict(reason=reason, ok=res['ok'], expansions=res['expansions'], time=res['time'],
                                    length=self._len(res['path'])))
        self.log['events'].append((self.t, f"plan ({reason}): {'ok' if res['ok'] else 'FAILED'}, {res['expansions']} expansions, {res['time']:.2f}s"))
        if res['ok']:
            self.follower.set_path(res['path'])
            self.log['paths'].append((self.t, np.array(res['path'])))
            self.current_path = np.array(res['path'])
        return res['ok']

    @staticmethod
    def _len(path):
        return float(sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(path, path[1:]))) if len(path) > 1 else 0.0

    def path_blocked_by(self, pts, clearance=1.3, horizon=25.0):
        if not len(pts) or self.current_path is None:
            return False
        P = self.current_path[:, :2]
        i0 = int(np.argmin(np.hypot(P[:, 0] - self.veh.x, P[:, 1] - self.veh.y)))
        seg = P[i0:i0 + int(horizon / 0.25)]
        d = np.hypot(seg[:, None, 0] - pts[None, :, 0], seg[:, None, 1] - pts[None, :, 1])
        return bool(d.min() < clearance)

    def car_collides(self):
        poly = L.car_polygon(*self.veh.pose)
        a, b = poly[0], poly[1]; d = poly[3]
        for u in np.linspace(0, 1, 9):
            for w in np.linspace(0, 1, 5):
                p = a + u * (b - a) + w * (d - a)
                if self.world.occupied(p[0], p[1]):
                    return True
        return False

    # ---- main loop ----
    def run(self):
        w0 = time.perf_counter()
        self.current_path = None
        if not self.plan('initial'):
            self.status = 'no initial path'
            return False
        blocked_since, last_replan = None, -9.0
        scan = self.lidar.scan(self.world, self.veh.pose)
        while self.t < self.max_time:
            if self.cart and self.t >= self.cart[2] and not self.world.dynamic.any():
                self.world.add_box(self.cart[0], self.cart[1])
                self.log['events'].append((self.t, 'shopping cart appears in the aisle'))
            if int(self.t / self.dt) % 2 == 0:
                scan = self.lidar.scan(self.world, self.veh.pose)
            pts = scan_points_world(self.veh.pose, scan, self.lidar.rel)
            unk = unknown_obstacle_points(pts, self.static_known)
            # detected obstacle -> add to the planner's map; replan if it threatens the current route
            if len(unk):
                add = np.zeros_like(self.known)
                for x, y in unk:
                    add[int(y / L.RES), int(x / L.RES)] = True
                new = add & ~self.known
                if new.any():
                    self.known |= dilate(new, 3)      # lidar sees only the near face: assume the obstacle extends ~0.75 m behind it
                    if self.t - last_replan > 1.0 and self.path_blocked_by(unk):
                        last_replan = self.t
                        self.replans += 1
                        self.log['events'].append((self.t, 'obstacle on route -> replanning'))
                        if not self.plan('replan'):
                            self.status = 'replan failed'
                            break
            v_cmd, d_cmd, st = self.follower.command(self.veh.pose, self.veh.v, unk, self.dt)
            if st == 'blocked':
                blocked_since = self.t if blocked_since is None else blocked_since
                if self.t - blocked_since > 1.5 and self.t - last_replan > 1.0:
                    last_replan = self.t; self.replans += 1; blocked_since = None
                    self.log['events'].append((self.t, 'blocked -> replanning'))
                    if not self.plan('blocked'):
                        self.status = 'replan failed'
                        break
            else:
                blocked_since = None
            x0, y0 = self.veh.x, self.veh.y
            self.veh.step(v_cmd, d_cmd, self.dt)
            self.dist += math.hypot(self.veh.x - x0, self.veh.y - y0)
            self.t += self.dt
            col = self.car_collides()
            if col and not self._col:
                self.collisions += 1
                self.log['events'].append((self.t, 'COLLISION'))
            self._col = col
            for k, val in (('t', self.t), ('x', self.veh.x), ('y', self.veh.y), ('th', self.veh.th), ('v', self.veh.v), ('delta', self.veh.delta)):
                self.log[k].append(val)
            self.log['scans'].append(scan.copy() if len(self.log['t']) % 2 == 0 else None)
            if st == 'arrived' and abs(self.veh.v) < 0.02:
                self.status = 'arrived'
                self.log['events'].append((self.t, 'ARRIVED / parked'))
                break
        else:
            self.status = 'timeout'
        self.wall = time.perf_counter() - w0
        return self.status == 'arrived'

    def metrics(self):
        gx, gy, gth = self.goal
        c, s = math.cos(gth), math.sin(gth)
        dx, dy = self.veh.x - gx, self.veh.y - gy
        along, lat = dx * c + dy * s, -dx * s + dy * c
        herr = math.degrees(abs(L.wrap_pi(self.veh.th - gth)))
        poly = L.car_polygon(*self.veh.pose)
        cx = L.bay_center_x(self.bay)
        y0, y1 = (L.TOP_Y0, L.TOP_Y1) if self.bay < 10 else (L.BOT_Y0, L.BOT_Y1)
        inside = bool(np.all((poly[:, 0] > cx - L.BAY_W / 2) & (poly[:, 0] < cx + L.BAY_W / 2) & (poly[:, 1] > y0 - 0.01) & (poly[:, 1] < y1)))
        return dict(status=self.status, time=self.t, distance=self.dist, lateral_err=abs(lat), longitudinal_err=abs(along),
                    heading_err_deg=herr, inside_bay=inside, collisions=self.collisions, replans=self.replans,
                    plans=self.plan_stats)

    def report(self):
        m = self.metrics()
        lines = ['=' * 84, f"Mission status: {m['status'].upper()}   bay {self.bay} ({'reverse-in' if self.reverse_in else 'nose-in'})",
                 f"Time {m['time']:.1f} s | distance driven {m['distance']:.1f} m | collisions {m['collisions']} | replans {m['replans']}",
                 f"Final pose error: lateral {m['lateral_err']*100:.1f} cm, longitudinal {m['longitudinal_err']*100:.1f} cm, heading {m['heading_err_deg']:.1f} deg",
                 f"Whole car inside the bay lines: {m['inside_bay']}", 'Planner runs:']
        for p in m['plans']:
            lines.append(f"   {p['reason']:<8} ok={p['ok']} expansions={p['expansions']:>6} time={p['time']:.2f}s path={p['length']:.1f} m")
        lines += ['Disclaimer: simulation only - not evidence of real-world safety.', '=' * 84]
        return '\n'.join(lines)


def run_tests():
    ok_all = True

    def check(name, cond, info=''):
        nonlocal ok_all
        ok_all &= bool(cond)
        print(f"[{'PASS' if cond else 'FAIL'}] {name} {info}")

    from .core.hybrid_astar import arc_step, infer_directions
    # bicycle kinematics
    b = Bicycle((0, 0, 0)); b.delta = 0.3
    for _ in range(400):
        b.step(1.0, 0.3, 0.05)
    R = L.WHEELBASE / math.tan(0.3)
    check('Bicycle: constant steering drives a circle of radius L/tan(delta)', abs(math.hypot(b.x, b.y - R) - R) < 0.05, f'(R={R:.2f} m)')
    x, y, th = arc_step(0, 0, 0, 1.0, 0.0)
    check('arc_step straight', abs(x - 1) < 1e-12 and abs(y) < 1e-12)
    x, y, th = arc_step(0, 0, 0, -2.0, 0.4); x2, y2, th2 = arc_step(x, y, th, 2.0, 0.4)
    check('arc_step: reverse then forward with the same steering returns to start', abs(x2) < 1e-9 and abs(y2) < 1e-9 and abs(th2) < 1e-9)
    # lot / collision
    w = L.LotWorld()
    check('World: aisle centre is free, parked car cell is occupied', (not w.occupied(15, 14)) and w.occupied(*[(L.parked_car_rect(0)[0] + L.parked_car_rect(0)[2]) / 2, 21.0]))
    pl = HybridAStar(w.static)
    check('Collision: start pose is free, pose inside a parked car is not', pl.pose_free(*L.START_POSE) and not pl.pose_free(L.bay_center_x(0), 21.0, math.pi / 2))
    # planning
    for bay, rev in ((6, True), (12, True), (3, False)):
        r = pl.plan(L.START_POSE, L.bay_goal_pose(bay, rev))
        d = infer_directions(r['path']) if r['ok'] else []
        check(f'Hybrid A*: plans to bay {bay} ({"reverse" if rev else "nose-in"})', r['ok'] and (not rev or -1 in d), f"({r['expansions']} expansions, {r['time']:.2f}s, reverse used={-1 in d})")
        if r['ok']:
            check(f'Hybrid A*: bay {bay} path is collision free and ends at the goal', all(pl.pose_free(*p) for p in r['path']) and math.hypot(r['path'][-1][0] - L.bay_goal_pose(bay, rev)[0], r['path'][-1][1] - L.bay_goal_pose(bay, rev)[1]) < 0.6)
    wblock = L.LotWorld(); wblock.static[:, int(10 / L.RES):int(11 / L.RES)] = True      # wall across the whole lot
    r = HybridAStar(wblock.static).plan(L.START_POSE, L.bay_goal_pose(6))
    check('Hybrid A*: reports failure when the goal is unreachable (no crash)', not r['ok'], f"({r['reason']})")
    r = pl.plan(L.START_POSE, L.bay_goal_pose(0))
    check('Hybrid A*: goal inside an occupied bay is rejected', not r['ok'], f"({r['reason']})")
    # lidar + map differencing
    rng = np.random.default_rng(0); lid = Lidar(rng)
    w.add_box(10, 14)
    sc = lid.scan(w, (3, 14, 0)); k = int(np.argmin(np.abs(lid.rel)))
    check('Lidar: sees a 1 m cart 7 m ahead (about 6.5 m to its face)', abs(sc[k] - 6.5) < 0.2, f'(range {sc[k]:.2f} m)')
    unk = unknown_obstacle_points(scan_points_world((3, 14, 0), sc, lid.rel), L.LotWorld().static)
    check('Map differencing: only the cart is reported as unknown (walls/cars ignored)', 1 <= len(unk) < 40 and np.all(np.abs(unk[:, 0] - 9.5) < 0.6), f'({len(unk)} points)')
    # full missions
    m1 = ValetMission(bay=6, cart=None); m1.run(); r1 = m1.metrics()
    check('Mission (no cart): parks, 0 collisions, car inside bay lines', m1.status == 'arrived' and r1['collisions'] == 0 and r1['inside_bay'], f"(lat {r1['lateral_err']*100:.0f} cm, head {r1['heading_err_deg']:.1f} deg, {r1['time']:.0f} s)")
    m2 = ValetMission(bay=6); m2.run(); r2 = m2.metrics()
    check('Mission (cart appears): detects it, replans at least once, parks, 0 collisions', m2.status == 'arrived' and r2['replans'] >= 1 and r2['collisions'] == 0 and r2['inside_bay'], f"({r2['replans']} replans, {r2['time']:.0f} s)")
    m3 = ValetMission(bay=16, reverse_in=False, cart=None); m3.run()
    check('Mission (other row, nose-in): parks inside bay', m3.status == 'arrived' and m3.metrics()['inside_bay'], f"({m3.status})")
    print('\nALL TESTS PASSED' if ok_all else '\nSOME TESTS FAILED')
    return ok_all


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--test', action='store_true')
    ap.add_argument('--bay', type=int, default=6, help='empty bay index: free bays are 3, 6 (top row), 12, 16 (bottom row)')
    ap.add_argument('--forward-in', action='store_true')
    ap.add_argument('--no-cart', action='store_true')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--out', default=str(OUT_DIR))
    ap.add_argument('--show', action='store_true')
    a = ap.parse_args()
    if a.test:
        sys.exit(0 if run_tests() else 1)
    if a.bay in L.OCCUPIED_BAYS:
        sys.exit(f'Bay {a.bay} is occupied. Free bays: {sorted(set(range(20)) - L.OCCUPIED_BAYS)}')
    m = ValetMission(bay=a.bay, reverse_in=not a.forward_in, cart=None if a.no_cart else (17.0, 14.0, 4.0), seed=a.seed)
    print('Simulating ...')
    m.run()
    print(m.report())
    for t, e in m.log['events']:
        print(f'  t={t:6.1f}s  {e}')
    saved = render_outputs(m.log, a.out, show=a.show)
    print(f'Saved to {a.out}:'); [print('   ', s) for s in saved]


if __name__ == '__main__':
    main()
