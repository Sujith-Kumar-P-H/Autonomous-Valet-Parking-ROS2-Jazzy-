"""Small helpers shared by the ROS 2 nodes (message <-> plain Python conversions)."""
import math

import numpy as np
from geometry_msgs.msg import PoseStamped, Quaternion
from nav_msgs.msg import Path
from rclpy.qos import QoSProfile, DurabilityPolicy, ReliabilityPolicy, HistoryPolicy

from av_valet.core import lot as L

# Latched ("transient local") QoS: late subscribers (e.g. RViz started after the map node) still receive the last map.
LATCHED_QOS = QoSProfile(depth=1, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                         reliability=ReliabilityPolicy.RELIABLE, history=HistoryPolicy.KEEP_LAST)


def yaw_to_quat(yaw):
    return Quaternion(x=0.0, y=0.0, z=math.sin(yaw / 2), w=math.cos(yaw / 2))


def quat_to_yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


def path_to_msg(path_xyth, stamp, frame='map'):
    msg = Path()
    msg.header.frame_id, msg.header.stamp = frame, stamp
    for x, y, th in path_xyth:
        ps = PoseStamped()
        ps.header = msg.header
        ps.pose.position.x, ps.pose.position.y = float(x), float(y)
        ps.pose.orientation = yaw_to_quat(float(th))
        msg.poses.append(ps)
    return msg


def msg_to_path(msg):
    return [(p.pose.position.x, p.pose.position.y, quat_to_yaw(p.pose.orientation)) for p in msg.poses]


def grid_from_occupancy(msg):
    """nav_msgs/OccupancyGrid -> bool numpy grid with the same [iy, ix] convention as core.lot."""
    g = np.array(msg.data, dtype=np.int8).reshape(msg.info.height, msg.info.width)
    return g > 50
