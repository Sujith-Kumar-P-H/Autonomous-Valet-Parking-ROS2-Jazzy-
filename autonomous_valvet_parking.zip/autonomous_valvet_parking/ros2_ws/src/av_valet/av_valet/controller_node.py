#!/usr/bin/env python3
"""controller_node: pure-pursuit path follower with sequencing of forward/reverse segments and rule-based emergency braking.
  subscribes : /planned_path, /odom, /scan, /map
  publishes  : /cmd_vel (Twist: linear.x speed, angular.z steering angle), /controller_status (std_msgs/String:
               idle | tracking | switching | blocked | arrived)   at 20 Hz"""
import numpy as np
import rclpy
from geometry_msgs.msg import Twist
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

from av_valet.core.vehicle import PathFollower, scan_points_world, unknown_obstacle_points
from av_valet.ros_utils import LATCHED_QOS, grid_from_occupancy, msg_to_path, quat_to_yaw


class ControllerNode(Node):
    def __init__(self):
        super().__init__('controller_node')
        self.follower = PathFollower()
        self.pose, self.v, self.static, self.unk = None, 0.0, None, np.zeros((0, 2))
        self.dt = 0.05
        self.create_subscription(Path, '/planned_path', self.on_path, 10)
        self.create_subscription(Odometry, '/odom', self.on_odom, 10)
        self.create_subscription(LaserScan, '/scan', self.on_scan, 10)
        self.create_subscription(OccupancyGrid, '/map', self.on_map, LATCHED_QOS)
        self.pub_cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.pub_status = self.create_publisher(String, '/controller_status', 10)
        self.create_timer(self.dt, self.loop)
        self.get_logger().info('controller_node ready')

    def on_map(self, msg):
        if self.static is None:
            self.static = grid_from_occupancy(msg)

    def on_odom(self, msg):
        p = msg.pose.pose
        self.pose = (p.position.x, p.position.y, quat_to_yaw(p.orientation))
        self.v = msg.twist.twist.linear.x

    def on_scan(self, msg):
        if self.pose is None or self.static is None:
            return
        rel = msg.angle_min + msg.angle_increment * np.arange(len(msg.ranges))
        self.unk = unknown_obstacle_points(scan_points_world(self.pose, np.array(msg.ranges), rel, msg.range_max), self.static)

    def on_path(self, msg):
        path = msg_to_path(msg)
        if len(path) > 1:
            self.follower.set_path(path)
            self.get_logger().info(f'new path with {len(path)} poses, {len(self.follower.segs)} segment(s)')

    def loop(self):
        if self.pose is None:
            return
        v, delta, status = self.follower.command(self.pose, self.v, self.unk, self.dt)
        cmd = Twist()
        cmd.linear.x, cmd.angular.z = float(v), float(delta)
        self.pub_cmd.publish(cmd)
        self.pub_status.publish(String(data=status))


def main(args=None):
    rclpy.init(args=args)
    node = ControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
