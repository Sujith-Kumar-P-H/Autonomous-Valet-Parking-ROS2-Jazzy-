#!/usr/bin/env python3
"""recorder_node: records the run from ROS topics and, when the vehicle has parked (or on timeout / Ctrl+C), writes
PNG images and an MP4 video (GIF fallback) to  ~/robot_sim_outputs/av_valet/  with the prefix `ros2_`.
Then it exits (the launch file shuts everything down when this node exits).
Parameters: out_dir (default ~/robot_sim_outputs/av_valet), timeout (s, default 150), bay (for the picture title)."""
import math
import os
from pathlib import Path as FsPath

import numpy as np
import rclpy
from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Odometry, Path
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String

from av_valet.core.render import render_outputs
from av_valet.ros_utils import msg_to_path, quat_to_yaw


class RecorderNode(Node):
    def __init__(self):
        super().__init__('recorder_node')
        self.declare_parameter('out_dir', str(FsPath.home() / 'robot_sim_outputs' / 'av_valet'))
        self.declare_parameter('timeout', 150.0)
        self.declare_parameter('bay', 6)
        self.t0 = None
        self.log = dict(t=[], x=[], y=[], th=[], v=[], delta=[], scans=[], rel=None, paths=[], cart=None, bay=int(self.get_parameter('bay').value), events=[])
        self.cmd_delta, self.last_scan, self.status, self.arrived_at = 0.0, None, 'idle', None
        self.finished = False
        self.create_subscription(Odometry, '/odom', self.on_odom, 20)
        self.create_subscription(Twist, '/cmd_vel', lambda m: setattr(self, 'cmd_delta', m.angular.z), 10)
        self.create_subscription(LaserScan, '/scan', self.on_scan, 10)
        self.create_subscription(Path, '/planned_path', self.on_path, 10)
        self.create_subscription(PoseStamped, '/cart_pose', self.on_cart, 10)
        self.create_subscription(String, '/controller_status', self.on_status, 10)
        self.create_timer(0.5, self.check_end)
        self.get_logger().info('recorder_node ready; will save images/video to ' + self.get_parameter('out_dir').value)

    def t(self):
        return self.get_clock().now().nanoseconds * 1e-9 - (self.t0 or 0.0)

    def on_odom(self, m):
        if self.t0 is None:
            self.t0 = self.get_clock().now().nanoseconds * 1e-9
        p = m.pose.pose
        self.log['t'].append(self.t()); self.log['x'].append(p.position.x); self.log['y'].append(p.position.y)
        self.log['th'].append(quat_to_yaw(p.orientation)); self.log['v'].append(m.twist.twist.linear.x)
        self.log['delta'].append(self.cmd_delta)
        self.log['scans'].append(self.last_scan if len(self.log['t']) % 5 == 0 else None)

    def on_scan(self, m):
        self.last_scan = list(m.ranges)
        if self.log['rel'] is None:
            self.log['rel'] = (m.angle_min + m.angle_increment * np.arange(len(m.ranges))).tolist()

    def on_path(self, m):
        self.log['paths'].append((self.t(), np.array(msg_to_path(m))))
        self.log['events'].append((self.t(), f'new path ({len(m.poses)} poses)'))

    def on_cart(self, m):
        self.log['cart'] = (m.pose.position.x, m.pose.position.y, self.t())
        self.log['events'].append((self.t(), 'shopping cart appears'))

    def on_status(self, m):
        if m.data != self.status:
            self.log['events'].append((self.t(), f'controller: {m.data}'))
        self.status = m.data
        if m.data == 'arrived' and self.arrived_at is None:
            self.arrived_at = self.t()

    def check_end(self):
        if self.t0 is None or self.finished:
            return
        if (self.arrived_at is not None and self.t() - self.arrived_at > 2.0) or self.t() > self.get_parameter('timeout').value:
            self.save()

    def save(self):
        if self.finished or len(self.log['t']) < 10 or not self.log['paths']:
            return
        self.finished = True
        self.get_logger().info('rendering images and video ... (about 1 minute)')
        saved = render_outputs(self.log, self.get_parameter('out_dir').value, prefix='ros2_')
        self.get_logger().info('saved to ' + self.get_parameter('out_dir').value + ': ' + ', '.join(saved))
        raise SystemExit(0)


def main(args=None):
    rclpy.init(args=args)
    node = RecorderNode()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        if not node.finished:
            try:
                node.save()
            except SystemExit:
                pass
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
