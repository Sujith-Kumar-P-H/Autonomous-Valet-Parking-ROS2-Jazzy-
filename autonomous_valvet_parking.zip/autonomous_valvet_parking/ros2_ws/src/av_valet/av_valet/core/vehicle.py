"""
vehicle.py -- kinematic bicycle model, simulated lidar, path follower (pure pursuit) and obstacle detection.  NO ROS imports.

CATEGORIES:  bicycle model / pure pursuit / ray casting = classical robotics;
             speed limits, stop-and-reverse sequencing, emergency braking, map-differencing obstacle test = rule-based;
             trained AI = none.

KINEMATIC BICYCLE (rear-axle reference point):
    xdot = v cos(theta),  ydot = v sin(theta),  thetadot = v tan(delta) / L        (v < 0 means reversing)
Valid at parking speeds (no tyre slip, no suspension). Steering angle and rate and acceleration are limited.

PURE PURSUIT (forward):   alpha = angle of the look-ahead point in the vehicle frame,  delta = atan(2 L sin(alpha) / Ld)
PURE PURSUIT (reverse):   the car moves along theta+pi, and thetadot = -|v| tan(delta)/L, so  delta = -atan(2 L sin(alpha_r) / Ld)
                          with alpha_r measured from the direction of travel.
"""
from __future__ import annotations

import math

import numpy as np

from . import lot as L
from .lot import WHEELBASE, wrap_pi
from .hybrid_astar import DELTA_MAX, infer_directions


class Bicycle:
    def __init__(self, pose, v_max=2.5, a_acc=1.5, a_dec=3.0, steer_rate=0.8):
        self.x, self.y, self.th = pose
        self.v = 0.0
        self.delta = 0.0
        self.v_max, self.a_acc, self.a_dec, self.steer_rate = v_max, a_acc, a_dec, steer_rate

    def step(self, v_cmd, delta_cmd, dt):
        v_cmd = float(np.clip(v_cmd, -self.v_max, self.v_max))
        delta_cmd = float(np.clip(delta_cmd, -DELTA_MAX, DELTA_MAX))
        a = self.a_dec if abs(v_cmd) < abs(self.v) or v_cmd * self.v < 0 else self.a_acc
        self.v += float(np.clip(v_cmd - self.v, -a * dt, a * dt))
        self.delta += float(np.clip(delta_cmd - self.delta, -self.steer_rate * dt, self.steer_rate * dt))
        k = math.tan(self.delta) / WHEELBASE
        if abs(k) < 1e-9 or abs(self.v) < 1e-9:
            self.x += self.v * dt * math.cos(self.th)
            self.y += self.v * dt * math.sin(self.th)
        else:
            th2 = self.th + self.v * dt * k
            self.x += (math.sin(th2) - math.sin(self.th)) / k
            self.y -= (math.cos(th2) - math.cos(self.th)) / k
            self.th = wrap_pi(th2)

    @property
    def pose(self):
        return (self.x, self.y, self.th)


class Lidar:
    """360 deg, n beams, range noise sigma. Mounted at the rear-axle point."""

    def __init__(self, rng, n=180, max_range=15.0, sigma=0.03):
        self.rng, self.n, self.max_range, self.sigma = rng, n, max_range, sigma
        self.rel = np.linspace(-math.pi, math.pi, n, endpoint=False)

    def scan(self, world, pose):
        r = L.cast_rays(world.true_grid, pose[0], pose[1], pose[2] + self.rel, self.max_range)
        hit = r < self.max_range - 1e-6
        return np.where(hit, np.clip(r + self.rng.normal(0, self.sigma, r.shape), 0.05, self.max_range), r)


def scan_points_world(pose, ranges, rel, max_range=15.0):
    hit = ranges < max_range - 1e-6
    a = pose[2] + rel[hit]
    return np.c_[pose[0] + ranges[hit] * np.cos(a), pose[1] + ranges[hit] * np.sin(a)]


def unknown_obstacle_points(pts, known_grid):
    """Map differencing: keep only lidar hits that are NOT explained by the known map (cell or any neighbour occupied).
    LIMITATION: a real vehicle cannot rely on the map for emergency braking; this is a simplification so that walls and
    parked cars (already in the map) never trigger a stop while docking."""
    out = []
    for x, y in pts:
        ix, iy = int(x / L.RES), int(y / L.RES)
        if not (1 <= ix < L.W - 1 and 1 <= iy < L.H - 1):
            continue
        if not known_grid[iy - 1:iy + 2, ix - 1:ix + 2].any():
            out.append((x, y))
    return np.array(out).reshape(-1, 2)


class PathFollower:
    """Follows a path made of forward/reverse segments. Returns (v_cmd, delta_cmd, status).
    status: 'idle' | 'tracking' | 'switching' | 'blocked' | 'arrived'."""

    def __init__(self, v_fwd=2.2, v_rev=1.0, a_dec=0.9, a_lat=1.5, brake_margin=1.6, goal_tol=0.15, switch_dwell=0.8):
        self.v_fwd, self.v_rev, self.a_dec, self.a_lat = v_fwd, v_rev, a_dec, a_lat
        self.brake_margin, self.goal_tol, self.switch_dwell = brake_margin, goal_tol, switch_dwell
        self.segs, self.si, self.dwell_t = [], 0, 0.0
        self.status = 'idle'

    def set_path(self, path):
        """path: list of (x, y, theta). Splits it into segments of constant travel direction."""
        dirs = infer_directions(path)
        self.segs, cur = [], [0]
        for i in range(1, len(path)):
            if dirs[i] != dirs[cur[0]] and len(cur) > 1:
                self.segs.append((dirs[cur[0]], np.array([[path[j][0], path[j][1]] for j in cur + [i]])))   # share the cusp point
                cur = [i]
            else:
                cur.append(i)
        self.segs.append((dirs[cur[0]], np.array([[path[j][0], path[j][1]] for j in cur])))
        self.si, self.dwell_t, self.status = 0, 0.0, 'tracking'

    def _nearest(self, pts, p):
        d = np.hypot(pts[:, 0] - p[0], pts[:, 1] - p[1])
        return int(np.argmin(d))

    def command(self, pose, v_meas, obstacle_pts, dt):
        if self.status in ('idle', 'arrived') or not self.segs:
            return 0.0, 0.0, self.status
        dr, pts = self.segs[self.si]
        x, y, th = pose
        i0 = self._nearest(pts, (x, y))
        seg_len = float(np.sum(np.hypot(*np.diff(pts, axis=0).T)))
        s_done = float(np.sum(np.hypot(*np.diff(pts[:i0 + 1], axis=0).T))) if i0 > 0 else 0.0
        dist_end = max(seg_len - s_done, 0.0)
        # ---- end of segment: stop, then (maybe) switch direction ----
        if dist_end < self.goal_tol or (i0 >= len(pts) - 1):
            if self.si == len(self.segs) - 1:
                self.status = 'arrived'
                return 0.0, 0.0, self.status
            if abs(v_meas) > 0.05:
                self.status = 'switching'
                return 0.0, 0.0, self.status
            self.dwell_t += dt
            self.status = 'switching'
            if self.dwell_t >= self.switch_dwell:
                self.si += 1
                self.dwell_t = 0.0
            return 0.0, 0.0, self.status
        # ---- look-ahead point ----
        Ld = max(1.6, 0.8 + 0.9 * abs(v_meas)) if dr > 0 else 1.6
        j, acc = i0, 0.0
        while j < len(pts) - 1 and acc < Ld:
            acc += float(np.hypot(*(pts[j + 1] - pts[j])))
            j += 1
        tx, ty = pts[j]
        head = th if dr > 0 else th + math.pi
        alpha = wrap_pi(math.atan2(ty - y, tx - x) - head)
        ld = max(math.hypot(tx - x, ty - y), 0.5)
        k = 2 * math.sin(alpha) / ld
        delta = math.atan(WHEELBASE * k)
        if dr < 0:
            delta = -delta
        delta = max(-DELTA_MAX, min(DELTA_MAX, delta))
        # ---- speed ----
        v = self.v_fwd if dr > 0 else self.v_rev
        v = min(v, math.sqrt(2 * self.a_dec * max(dist_end - 0.05, 0.0)) + 0.15, math.sqrt(self.a_lat / max(abs(k), 1e-3)))
        v = max(v, 0.25 if dist_end > 0.4 else 0.15)
        # ---- emergency braking (rule-based): unknown obstacle inside the swept corridor ALONG THE PLANNED PATH ----
        blocked = False
        if len(obstacle_pts):
            bumper = L.FRONT_END if dr > 0 else L.REAR_OVERHANG
            d_stop = v_meas ** 2 / (2 * 2.5) + self.brake_margin
            s_ahead, ahead, acc_len, first = bumper + d_stop, [], 0.0, True
            for k in range(self.si, len(self.segs)):
                p = self.segs[k][1]
                start = i0 if first else 0
                first = False
                for m in range(start, len(p)):
                    if ahead:
                        acc_len += float(np.hypot(*(p[m] - ahead[-1])))
                    ahead.append(p[m])
                    if acc_len > s_ahead:
                        break
                if acc_len > s_ahead:
                    break
            A = np.array(ahead)
            dmin = float(np.min(np.hypot(A[:, None, 0] - obstacle_pts[None, :, 0], A[:, None, 1] - obstacle_pts[None, :, 1])))
            blocked = dmin < L.CAR_W / 2 + 0.25
        if blocked:
            self.status = 'blocked'
            return 0.0, delta, self.status
        self.status = 'tracking'
        return dr * v, delta, self.status
