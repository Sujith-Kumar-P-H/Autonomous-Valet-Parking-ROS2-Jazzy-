"""
render.py -- turns a recorded run into images + a video. Used by BOTH the standalone demo and the ROS recorder node,
so the outputs look identical. Everything is written to ~/robot_sim_outputs/av_valet/ by default.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from . import lot as L

OUT_DIR = Path.home() / 'robot_sim_outputs' / 'av_valet'


def make_video_writer(fps):
    import matplotlib
    import matplotlib.animation as animation
    try:
        import imageio_ffmpeg
        matplotlib.rcParams['animation.ffmpeg_path'] = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    if animation.writers.is_available('ffmpeg'):
        return 'mp4', animation.FFMpegWriter(fps=fps, bitrate=2000)
    return 'gif', animation.PillowWriter(fps=fps)


def draw_lot(ax, cart=None, goal_bay=None):
    from matplotlib.patches import Rectangle, Polygon
    ax.set_aspect('equal'); ax.set_xlim(0, 40); ax.set_ylim(4, 24.5)
    ax.add_patch(Rectangle((0, 23.5), 40, 5, color='0.55')); ax.add_patch(Rectangle((0, 0), 40, 4.5, color='0.55'))
    for i in range(20):
        top = i < 10
        x0, y0 = L.bay_center_x(i) - L.BAY_W / 2, (L.TOP_Y0 if top else L.BOT_Y0)
        ax.add_patch(Rectangle((x0, y0), L.BAY_W, (L.TOP_Y1 - L.TOP_Y0) if top else (L.BOT_Y1 - L.BOT_Y0),
                               fill=False, ec='white' if i != goal_bay else 'limegreen', lw=1 if i != goal_bay else 2.5))
        if i in L.OCCUPIED_BAYS:
            r = L.parked_car_rect(i)
            ax.add_patch(Rectangle((r[0], r[1]), r[2] - r[0], r[3] - r[1], fc='tab:blue', ec='k', alpha=.75))
    ax.set_facecolor('0.30')
    if cart is not None:
        ax.add_patch(Rectangle((cart[0] - .5, cart[1] - .5), 1, 1, fc='orange', ec='k', zorder=4))
    ax.set_xlabel('x [m]'); ax.set_ylabel('y [m]')


def render_outputs(log, out_dir=None, prefix='', show=False, max_frames=220):
    """log keys: t,x,y,th,v,delta (arrays); scans (list of ranges or None); rel (beam angles); paths [(t, Nx3 array)];
    cart (x, y, t_appear) or None; bay (int); events [(t, text)]; metrics (dict)"""
    import matplotlib
    if not show:
        matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.animation import FuncAnimation
    from matplotlib.patches import Polygon
    out = Path(out_dir) if out_dir else OUT_DIR
    out.mkdir(parents=True, exist_ok=True)
    t, X, Y, TH = (np.asarray(log[k]) for k in ('t', 'x', 'y', 'th'))
    V, D = np.asarray(log['v']), np.asarray(log['delta'])
    saved = []
    cart = log.get('cart')
    paths = log.get('paths', [])

    # ---- static image 1: route overview ----
    fig, ax = plt.subplots(figsize=(12, 6))
    draw_lot(ax, cart, log.get('bay'))
    for k, (tp, p) in enumerate(paths):
        p = np.asarray(p)
        ax.plot(p[:, 0], p[:, 1], '--', lw=1.2, color='yellow' if k < len(paths) - 1 else 'limegreen',
                label='superseded plan' if k == 0 and len(paths) > 1 else ('final plan' if k == len(paths) - 1 else None))
    ax.plot(X, Y, color='red', lw=1.6, label='driven trajectory')
    ax.add_patch(Polygon(L.car_polygon(X[-1], Y[-1], TH[-1]), closed=True, fc='tab:red', ec='k', alpha=.8, zorder=5))
    ax.plot(X[0], Y[0], 'ko'); ax.legend(loc='lower right', fontsize=8)
    ax.set_title(f"Autonomous valet parking - bay {log.get('bay')} (simulation)")
    fig.tight_layout(); fig.savefig(out / f'{prefix}route_overview.png', dpi=130); plt.close(fig); saved.append(f'{prefix}route_overview.png')

    # ---- static image 2: speed and steering ----
    fig, axs = plt.subplots(2, 1, figsize=(10, 5.5), sharex=True)
    axs[0].plot(t, V); axs[0].axhline(0, color='k', lw=.5); axs[0].set_ylabel('speed v [m/s] (negative = reverse)'); axs[0].grid(alpha=.3)
    axs[1].plot(t, np.degrees(D), color='tab:orange'); axs[1].set_ylabel('steering angle [deg]'); axs[1].set_xlabel('time [s]'); axs[1].grid(alpha=.3)
    for te, txt in log.get('events', []):
        axs[0].axvline(te, color='gray', lw=.6, ls=':')
    fig.suptitle('Speed and steering over the run'); fig.tight_layout(); fig.savefig(out / f'{prefix}speed_steering.png', dpi=130); plt.close(fig)
    saved.append(f'{prefix}speed_steering.png')

    # ---- animation ----
    fig = plt.figure(figsize=(13, 6.5))
    gs = fig.add_gridspec(2, 2, width_ratios=[2.6, 1])
    ax = fig.add_subplot(gs[:, 0]); axv = fig.add_subplot(gs[0, 1]); axd = fig.add_subplot(gs[1, 1])
    draw_lot(ax, None, log.get('bay'))
    cart_patch = matplotlib.patches.Rectangle((0, 0), 1, 1, fc='orange', ec='k', zorder=4)
    ax.add_patch(cart_patch); cart_patch.set_visible(False)
    path_line, = ax.plot([], [], '--', color='limegreen', lw=1.6)
    trail, = ax.plot([], [], color='red', lw=1.2)
    car = Polygon(L.car_polygon(X[0], Y[0], TH[0]), closed=True, fc='tab:red', ec='k', zorder=5); ax.add_patch(car)
    rays = matplotlib.collections.LineCollection([], colors='cyan', linewidths=.3, alpha=.5); ax.add_collection(rays)
    axv.plot(t, V, lw=1); axv.set_title('speed [m/s]'); axv.grid(alpha=.3); cv = axv.axvline(0, color='k')
    axd.plot(t, np.degrees(D), color='tab:orange', lw=1); axd.set_title('steering [deg]'); axd.set_xlabel('t [s]'); axd.grid(alpha=.3); cd = axd.axvline(0, color='k')
    txt = fig.text(0.01, 0.01, '', family='monospace', fontsize=9)
    stride = max(1, len(t) // max_frames)
    idx = list(range(0, len(t), stride)) + [len(t) - 1]
    ptimes = [p[0] for p in paths]
    scans, rel = log.get('scans'), log.get('rel')

    def draw(k):
        i = idx[k]
        car.set_xy(L.car_polygon(X[i], Y[i], TH[i]))
        trail.set_data(X[:i + 1], Y[:i + 1])
        cur = [j for j, tp in enumerate(ptimes) if tp <= t[i]]
        if cur:
            p = np.asarray(paths[cur[-1]][1]); path_line.set_data(p[:, 0], p[:, 1])
        if cart is not None:
            cart_patch.set_visible(t[i] >= cart[2]); cart_patch.set_xy((cart[0] - .5, cart[1] - .5))
        if scans is not None and scans[i] is not None:
            r = np.asarray(scans[i]); a = TH[i] + np.asarray(rel)
            rays.set_segments([[(X[i], Y[i]), (X[i] + rr * math.cos(aa), Y[i] + rr * math.sin(aa))] for rr, aa in zip(r[::3], a[::3])])
        cv.set_xdata([t[i], t[i]]); cd.set_xdata([t[i], t[i]])
        ev = [e for e in log.get('events', []) if e[0] <= t[i]]
        txt.set_text(f"t={t[i]:6.1f}s  v={V[i]:5.2f} m/s  steer={math.degrees(D[i]):6.1f} deg   {ev[-1][1] if ev else ''}")
        return []

    ani = FuncAnimation(fig, draw, frames=len(idx), interval=40, blit=False, repeat=False)
    fig.suptitle('Autonomous valet parking (simulation): Hybrid A* + pure pursuit')
    fig.tight_layout(rect=(0, 0.04, 1, 0.96))
    draw(len(idx) - 1); fig.savefig(out / f'{prefix}final_frame.png', dpi=130); saved.append(f'{prefix}final_frame.png')
    ext, writer = make_video_writer(20)
    ani.save(str(out / f'{prefix}valet_parking.{ext}'), writer=writer, dpi=90)
    saved.append(f'{prefix}valet_parking.{ext}')
    if show:
        plt.show()
    plt.close('all')
    return saved
