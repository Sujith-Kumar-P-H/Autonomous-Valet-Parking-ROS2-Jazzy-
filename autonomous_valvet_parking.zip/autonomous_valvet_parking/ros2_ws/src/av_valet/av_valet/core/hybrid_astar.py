"""
hybrid_astar.py -- Hybrid A* path planner for a car-like (kinematic bicycle) vehicle, with reverse driving.  NO ROS imports.

WHY HYBRID A*?  Plain grid A* ignores that a car cannot move sideways or turn on the spot. Hybrid A* searches over
CONTINUOUS poses (x, y, theta) produced by simulating the bicycle model, and uses a coarse grid (x, y, theta bins) only
to decide whether a pose has already been visited. Paths are therefore drivable by construction.

STATE            (x, y, theta) of the REAR AXLE centre.
MOTION PRIMITIVE drive an arc of signed length s = +/-STEP with steering angle delta in {-d, -d/2, 0, d/2, d}:
                     kappa = tan(delta)/L;   theta' = theta + s*kappa
                     x' = x + (sin(theta') - sin(theta))/kappa,  y' = y - (cos(theta') - cos(theta))/kappa  (kappa -> 0: straight)
COST g           step length (reverse x REV_PENALTY) + steering penalty + steering-change penalty + direction-switch penalty
HEURISTIC h      max( 2-D Dijkstra distance to the goal over the inflated obstacle grid  (knows about walls/cars),
                      straight-line distance )     -- both ignore the non-holonomic constraint, so h is a lower bound-ish guide
ANALYTIC TAIL    when close to the goal, try one straight segment (forward or reverse) onto the goal pose. This is the
                 simple stand-in for the Reeds-Shepp expansion used in production planners.
COMPLEXITY       State space is (X/r) * (Y/r) * (360/dtheta) bins; each expansion generates 10 successors, each needs O(#discs)
                 collision look-ups. Worst case O(N log N) with a binary heap over visited bins N; the heuristic keeps real runs
                 to a few thousand expansions.
"""
from __future__ import annotations

import heapq
import math
import time

import numpy as np

from . import lot as L
from .lot import WHEELBASE, RES, DISC_R, DISC_S, wrap_pi

STEP = 1.0
DELTA_MAX = 0.5                       # max steering angle [rad] -> min turning radius L/tan(0.5) = 4.76 m
DELTAS = (-DELTA_MAX, -DELTA_MAX / 2, 0.0, DELTA_MAX / 2, DELTA_MAX)
STATE_RES, N_THETA = 0.5, 60          # visited-state grid: 0.5 m x 0.5 m x 6 deg
REV_PENALTY, STEER_PEN, STEER_CHG_PEN, SWITCH_PEN = 2.0, 0.2, 0.5, 8.0


def arc_step(x, y, th, s, delta):
    k = math.tan(delta) / WHEELBASE
    if abs(k) < 1e-9:
        return x + s * math.cos(th), y + s * math.sin(th), th
    th2 = th + s * k
    return x + (math.sin(th2) - math.sin(th)) / k, y - (math.cos(th2) - math.cos(th)) / k, wrap_pi(th2)


class HybridAStar:
    def __init__(self, static_or_dynamic_grid):
        """grid: bool occupancy grid of everything the planner currently knows about (static map + detected obstacles)."""
        self.grid = static_or_dynamic_grid
        self.blocked = L.inflate(self.grid, DISC_R)              # disc centres must stay in free cells of this grid
        self._flat = self.blocked.ravel().tolist()
        self.W, self.H = L.W, L.H

    # ---- collision ----
    def pose_free(self, x, y, th):
        c, s = math.cos(th), math.sin(th)
        for d in DISC_S:
            ix, iy = int((x + c * d) / RES), int((y + s * d) / RES)
            if not (0 <= ix < self.W and 0 <= iy < self.H) or self._flat[iy * self.W + ix]:
                return False
        return True

    def straight_free(self, x, y, th, s_total):
        n = max(1, int(abs(s_total) / (RES * 0.8)))
        for i in range(n + 1):
            xx, yy, tt = arc_step(x, y, th, s_total * i / n, 0.0)
            if not self.pose_free(xx, yy, tt):
                return False
        return True

    # ---- heuristic ----
    def holonomic_map(self, goal_xy):
        dist = np.full((self.H, self.W), np.inf)
        gx, gy = int(goal_xy[0] / RES), int(goal_xy[1] / RES)
        dist[gy, gx] = 0.0
        pq = [(0.0, gx, gy)]
        nb = [(1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0), (1, 1, 1.414), (1, -1, 1.414), (-1, 1, 1.414), (-1, -1, 1.414)]
        while pq:
            d, cx, cy = heapq.heappop(pq)
            if d > dist[cy, cx]:
                continue
            for dx, dy, c in nb:
                nx, ny = cx + dx, cy + dy
                if 0 <= nx < self.W and 0 <= ny < self.H and not self.blocked[ny, nx]:
                    nd = d + c * RES
                    if nd < dist[ny, nx]:
                        dist[ny, nx] = nd
                        heapq.heappush(pq, (nd, nx, ny))
        return dist

    @staticmethod
    def key(x, y, th):
        return int(x / STATE_RES), int(y / STATE_RES), int(((th + math.pi) / (2 * math.pi)) * N_THETA) % N_THETA

    # ---- search ----
    def plan(self, start, goal, w_h=1.4, max_expansions=60000, goal_tol=(0.3, math.radians(5)), tail_range=14.0):
        """Returns dict(ok, path=[(x,y,theta)...] densely sampled (0.25 m), expansions, time, reason)."""
        t0 = time.perf_counter()
        if not self.pose_free(*start):
            return dict(ok=False, reason='start pose in collision', path=[], expansions=0, time=0.0)
        if not self.pose_free(*goal):
            return dict(ok=False, reason='goal pose in collision', path=[], expansions=0, time=0.0)
        hol = self.holonomic_map(goal[:2])
        gx, gy, gth = goal

        def h(x, y):
            hv = hol[min(max(int(y / RES), 0), self.H - 1), min(max(int(x / RES), 0), self.W - 1)]
            return w_h * max(hv if np.isfinite(hv) else 1e3, math.hypot(gx - x, gy - y))

        nodes = [(start[0], start[1], start[2], 0, 0.0, 0.0, -1, [])]        # x,y,th,dir,delta,g,parent,pts
        pq = [(h(start[0], start[1]), 0, 0)]
        best = {self.key(*start): 0.0}
        counter, expansions = 1, 0
        while pq and expansions < max_expansions:
            _f, _c, nid = heapq.heappop(pq)
            x, y, th, dr, dl, g, par, _pts = nodes[nid]
            if g > best.get(self.key(x, y, th), 1e9) + 1e-9:
                continue
            expansions += 1
            dxg, dyg = gx - x, gy - y
            dist_goal = math.hypot(dxg, dyg)
            if dist_goal < goal_tol[0] and abs(wrap_pi(th - gth)) < goal_tol[1]:
                return self._finish(nodes, nid, [], t0, expansions)
            if dist_goal < tail_range:                # analytic straight tail onto the goal pose
                ca, sa = math.cos(gth), math.sin(gth)
                along, lat = dxg * ca + dyg * sa, -dxg * sa + dyg * ca
                if abs(lat) < 0.30 and abs(wrap_pi(th - gth)) < math.radians(6) and abs(along) > 0.05:
                    if self.straight_free(x, y, th, along) and self._tail_ok(x, y, th, gx, gy, gth):
                        n = max(2, int(abs(along) / 0.25))
                        tail = [(x + (gx - x) * i / n, y + (gy - y) * i / n, gth) for i in range(1, n + 1)]
                        return self._finish(nodes, nid, tail, t0, expansions, tail_dir=1 if along > 0 else -1)
            for sdir in (1, -1):
                for delta in DELTAS:
                    s = sdir * STEP
                    pts, cx, cy, cth, ok = [], x, y, th, True
                    for _ in range(4):                                        # 4 sub-steps of 0.25 m, each collision checked
                        cx, cy, cth = arc_step(cx, cy, cth, s / 4, delta)
                        if not self.pose_free(cx, cy, cth):
                            ok = False
                            break
                        pts.append((cx, cy, cth))
                    if not ok:
                        continue
                    cost = STEP * (REV_PENALTY if sdir < 0 else 1.0) + STEER_PEN * abs(delta) + STEER_CHG_PEN * abs(delta - dl)
                    if dr != 0 and sdir != dr:
                        cost += SWITCH_PEN
                    ng = g + cost
                    k = self.key(cx, cy, cth)
                    if ng < best.get(k, 1e9) - 1e-9:
                        best[k] = ng
                        nodes.append((cx, cy, cth, sdir, delta, ng, nid, pts))
                        heapq.heappush(pq, (ng + h(cx, cy), counter, len(nodes) - 1))
                        counter += 1
        return dict(ok=False, reason='no path found (expansion limit or blocked)', path=[], expansions=expansions, time=time.perf_counter() - t0)

    def _tail_ok(self, x, y, th, gx, gy, gth):
        n = max(2, int(math.hypot(gx - x, gy - y) / 0.2))
        return all(self.pose_free(x + (gx - x) * i / n, y + (gy - y) * i / n, gth if i == n else th + wrap_pi(gth - th) * i / n) for i in range(n + 1))

    def _finish(self, nodes, nid, tail, t0, expansions, tail_dir=1):
        chain = []
        while nid != -1:
            chain.append(nid)
            nid = nodes[nid][6]
        chain.reverse()
        path = [(nodes[chain[0]][0], nodes[chain[0]][1], nodes[chain[0]][2])]
        for c in chain[1:]:
            path.extend(nodes[c][7])
        path.extend(tail)
        return dict(ok=True, reason='ok', path=path, expansions=expansions, time=time.perf_counter() - t0)


def infer_directions(path):
    """Direction of travel (+1 forward, -1 reverse) for each path pose, from the angle between the heading and the
    local path tangent. This is how ROS nodes recover the direction from a plain nav_msgs/Path (no custom message)."""
    n = len(path)
    dirs = []
    for i in range(n):
        j = min(i + 1, n - 1)
        i0 = j - 1 if j == i else i
        dx, dy = path[j][0] - path[i0][0], path[j][1] - path[i0][1]
        if math.hypot(dx, dy) < 1e-9:
            dirs.append(dirs[-1] if dirs else 1)
            continue
        dirs.append(1 if abs(wrap_pi(math.atan2(dy, dx) - path[i][2])) < math.pi / 2 else -1)
    return dirs
