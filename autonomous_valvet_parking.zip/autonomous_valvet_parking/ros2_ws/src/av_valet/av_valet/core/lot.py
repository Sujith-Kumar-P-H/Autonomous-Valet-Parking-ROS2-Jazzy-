"""
lot.py -- parking-lot world model shared by every node (NO ROS imports here, so it can be unit-tested anywhere).

World frame "map": x right, y up, metres.  Grid index [iy, ix]; cell (ix, iy) covers [ix*RES, (ix+1)*RES).

Layout (40 m x 28 m):
    y 23.5-28  building / back wall           (occupied)
    y 18-23.5  TOP row of 10 bays   (index 0..9)    each 3.0 m wide, 5.5 m deep
    y 10-18    drive aisle (8 m wide)  <- vehicle enters from the left at (3, 14)
    y  4.5-10  BOTTOM row of 10 bays (index 10..19)
    y 0-4.5    back wall                      (occupied)
"""
from __future__ import annotations

import math

import numpy as np

RES = 0.25
W, H = 160, 112                      # 40 m x 28 m
WHEELBASE = 2.6
REAR_OVERHANG, FRONT_END = 0.9, 3.5  # body spans [-0.9, +3.5] m along the heading from the rear axle
CAR_L, CAR_W = REAR_OVERHANG + FRONT_END, 1.9
DISC_R = 1.2                         # collision discs radius (conservative)
DISC_S = (0.1, 1.0, 1.9, 2.8)        # disc centres along the heading, measured from the rear axle
BAY_W, BAY_X0 = 3.0, 7.5
TOP_Y0, TOP_Y1, BOT_Y0, BOT_Y1 = 18.0, 23.5, 4.5, 10.0
OCCUPIED_BAYS = {0, 1, 2, 4, 5, 7, 8, 9, 10, 11, 13, 14, 15, 17, 18, 19}
START_POSE = (3.0, 14.0, 0.0)


def wrap_pi(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


def bay_center_x(i):
    return BAY_X0 + BAY_W * ((i % 10) + 0.5)


def bay_goal_pose(i, reverse_in=True):
    """Rear-axle pose that parks a car in bay i. TOP-row bays open downward, BOTTOM-row bays open upward.
    reverse_in=True : nose points toward the aisle (the car backs in);  False: nose points into the bay."""
    x = bay_center_x(i)
    top = i < 10
    if top:
        if reverse_in:
            return (x, TOP_Y1 - 0.30 - REAR_OVERHANG - 0.1, -math.pi / 2)          # rear axle near the back wall
        return (x, TOP_Y1 - 0.60 - FRONT_END, math.pi / 2)
    if reverse_in:
        return (x, BOT_Y0 + 0.30 + REAR_OVERHANG + 0.1, math.pi / 2)
    return (x, BOT_Y0 + 0.60 + FRONT_END, -math.pi / 2)


def car_polygon(x, y, th, margin=0.0):
    """4 corners of the car body (rear axle pose x, y, th)."""
    c, s = math.cos(th), math.sin(th)
    pts = [(-REAR_OVERHANG - margin, -CAR_W / 2 - margin), (FRONT_END + margin, -CAR_W / 2 - margin),
           (FRONT_END + margin, CAR_W / 2 + margin), (-REAR_OVERHANG - margin, CAR_W / 2 + margin)]
    return np.array([[x + c * a - s * b, y + s * a + c * b] for a, b in pts])


def fill_rect(grid, x0, y0, x1, y1):
    ix0, ix1 = max(int(math.floor(x0 / RES)), 0), min(int(math.ceil(x1 / RES)), grid.shape[1])
    iy0, iy1 = max(int(math.floor(y0 / RES)), 0), min(int(math.ceil(y1 / RES)), grid.shape[0])
    grid[iy0:iy1, ix0:ix1] = True


def parked_car_rect(i):
    """Axis-aligned rectangle (x0, y0, x1, y1) of the car parked in bay i (cars sit centred, 0.3 m from the back)."""
    cx = bay_center_x(i)
    if i < 10:
        return cx - CAR_W / 2, TOP_Y1 - 0.3 - CAR_L, cx + CAR_W / 2, TOP_Y1 - 0.3
    return cx - CAR_W / 2, BOT_Y0 + 0.3, cx + CAR_W / 2, BOT_Y0 + 0.3 + CAR_L


def build_static_grid():
    g = np.zeros((H, W), bool)
    g[0, :] = g[-1, :] = True
    g[:, 0] = g[:, -1] = True
    fill_rect(g, 0, 0, 40, BOT_Y0)                       # lower wall
    fill_rect(g, 0, TOP_Y1, 40, 28)                      # upper wall
    # walls at the left/right of the bay rows, leaving the aisle open at x=0 (entrance) and x=40
    fill_rect(g, 0, BOT_Y0, 7.0, BOT_Y1); fill_rect(g, 0, TOP_Y0, 7.0, TOP_Y1)
    fill_rect(g, 38.0, BOT_Y0, 40, BOT_Y1); fill_rect(g, 38.0, TOP_Y0, 40, TOP_Y1)
    for i in OCCUPIED_BAYS:
        fill_rect(g, *parked_car_rect(i))
    return g


def inflate(grid, radius):
    """Grow occupied cells by `radius` metres (disc structuring element) using shifted copies."""
    rc = radius / RES
    k = int(math.ceil(rc))
    out = grid.copy()
    Hh, Ww = grid.shape
    for dy in range(-k, k + 1):
        for dx in range(-k, k + 1):
            if (dx or dy) and math.hypot(dx, dy) <= rc + 1e-9:
                ys_src = slice(max(0, -dy), min(Hh, Hh - dy)); ys_dst = slice(max(0, dy), min(Hh, Hh + dy))
                xs_src = slice(max(0, -dx), min(Ww, Ww - dx)); xs_dst = slice(max(0, dx), min(Ww, Ww + dx))
                out[ys_dst, xs_dst] |= grid[ys_src, xs_src]
    return out


def cast_rays(grid, x, y, angles, max_range=15.0, step=0.05):
    """Vectorised ray marching (simulated lidar). Returns ranges; max_range where nothing is hit."""
    s = np.arange(step, max_range + 1e-9, step)
    px, py = x + np.outer(np.cos(angles), s), y + np.outer(np.sin(angles), s)
    ix, iy = np.floor(px / RES).astype(int), np.floor(py / RES).astype(int)
    inside = (ix >= 0) & (ix < grid.shape[1]) & (iy >= 0) & (iy < grid.shape[0])
    occ = np.ones(px.shape, bool)
    occ[inside] = grid[iy[inside], ix[inside]]
    hit = occ.any(axis=1)
    first = occ.argmax(axis=1)
    return np.where(hit, s[first] - step / 2, max_range)


class LotWorld:
    """True world = static map + dynamic obstacles (e.g. a shopping cart that appears in the aisle)."""

    def __init__(self):
        self.static = build_static_grid()
        self.dynamic = np.zeros_like(self.static)

    @property
    def true_grid(self):
        return self.static | self.dynamic

    def add_box(self, cx, cy, w=1.0, h=1.0):
        fill_rect(self.dynamic, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)

    def occupied(self, x, y, grid=None):
        g = self.true_grid if grid is None else grid
        ix, iy = int(math.floor(x / RES)), int(math.floor(y / RES))
        return not (0 <= ix < W and 0 <= iy < H) or bool(g[iy, ix])
