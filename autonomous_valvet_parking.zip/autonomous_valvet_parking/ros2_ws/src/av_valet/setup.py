from setuptools import find_packages, setup

package_name = 'av_valet'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/valet.launch.py']),
        ('share/' + package_name + '/rviz', ['rviz/valet.rviz']),
    ],
    install_requires=['setuptools'],
    extras_require={'test': ['pytest']},
    zip_safe=True,
    maintainer='Student',
    maintainer_email='student@example.com',
    description='Autonomous valet parking simulation (Hybrid A*, pure pursuit) for ROS 2',
    license='MIT',
    entry_points={
        'console_scripts': [
            'map_node = av_valet.map_node:main',
            'vehicle_sim_node = av_valet.vehicle_sim_node:main',
            'planner_node = av_valet.planner_node:main',
            'controller_node = av_valet.controller_node:main',
            'mission_node = av_valet.mission_node:main',
            'recorder_node = av_valet.recorder_node:main',
            'valet_standalone = av_valet.standalone:main',
        ],
    },
)
